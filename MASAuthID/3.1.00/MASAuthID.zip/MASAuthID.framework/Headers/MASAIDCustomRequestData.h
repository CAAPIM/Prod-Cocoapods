//
//  MASAIDCustomRequestData.h
//  MASAuthID
//
//  Created by nimma01 on 26/03/18.
//  Copyright © 2018 CA. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MASAIDCustomRequestData : NSObject
{
    
}
@property (nonatomic)NSDictionary* headers;
@property (nonatomic)NSDictionary* queryParameters;
@property BOOL isPublic;

-(instancetype) init;
@end
