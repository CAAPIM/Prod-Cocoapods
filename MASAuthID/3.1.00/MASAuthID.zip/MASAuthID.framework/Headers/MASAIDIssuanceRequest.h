//
//  MASAIDIssuanceRequest.h
//  MASAuthID
//
//  Created by nimma01 on 26/03/18.
//  Copyright © 2018 CA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MASAIDCustomRequestData.h"

@interface MASAIDIssuanceRequest : NSObject
{
    
}

@property NSString* userName;
@property NSString* password;
@property NSString* orgName;
@property NSString* profileName;
@property NSString* clientTxID;
@property MASAIDCustomRequestData* customRequestData;

-(instancetype) init;

@end
