//
//  MASAuthID.h
//  MASAuthID
//
//  Created by Mahendra, Nimishakavi on 31/08/17.
//  Copyright © 2017 CA. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MASAuthID.
FOUNDATION_EXPORT double MASAuthIDVersionNumber;

//! Project version string for MASAuthID.
FOUNDATION_EXPORT const unsigned char MASAuthIDVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MASAuthID/PublicHeader.h>

#import <MASAuthID/MASUser+AuthID.h>
#import <MASAuthID/AIDAccount.h>

