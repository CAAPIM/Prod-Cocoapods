//
//  MASAuthIDConfig.h
//  MASAuthID
//
//  Created by sidki02 on 09/01/19.
//  Copyright © 2019 CA. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MASAuthIDConfig : NSObject
{
    
}

@property BOOL sharedAuthID;
//@property NSString* groupContainerIdentifier;

-(instancetype) init;

@end
