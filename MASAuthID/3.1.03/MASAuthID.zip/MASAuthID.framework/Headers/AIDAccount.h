//
//  AIDAccount.h
//  MASAdvancedAuth
//
//  Created by aniba01 on 04/04/17.
//  Copyright © 2017 CA Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AIDAccount : NSObject

/**
 *
 * The internal storage identifier of the AID.
 */
@property(nonatomic,strong) NSString *storageId;

/**
 *
 * The account identifier of the AID.
 */

@property(nonatomic,strong) NSString *accountId;
/**
 * 	URL of the logo image for this account
 *  --- Not set for now  ----
 */
@property(nonatomic,strong) NSString *logoUrl;


/**
 * A user friendly name
 */
@property(nonatomic,strong) NSString *name;


/**
 * 	The namespace of the AID.
 */
@property(nonatomic,strong) NSString *ns;

/**
 * 	The organization of the AID.
 */

@property(nonatomic,strong) NSString *org;

/**
 * 	The aid of the AID.
 */

@property(nonatomic,strong) NSString *aid;

/**
 * 	URL for provisioning of this account
 */
@property(nonatomic,strong) NSString *provUrl;

@property(nonatomic,strong) NSString *aidstr;

@property(nonatomic,strong) NSDate	 *creationdate;
@property(nonatomic,strong) NSDate	 *expirydate;
@property(nonatomic,strong) NSDate	 *lastused;
@property(nonatomic,strong) NSString *numuses;


@property(nonatomic,strong) NSMutableArray *custattr;

/**
 * Gets the value (as a string) to which the specified name is mapped, or NULL
 * if this object contains no mapping for the name.
 *
 * @param attrname - the name whose associated value is to be returned
 */
- (NSString *)getAttribute:(NSString *)attrname;


/**
 *
 * Gets the binary AID data (aid) as a Base64 encoded string
 *
 * @returns base64 encoded AID string
 *
 */
- (NSString *)getBase64Aid;

/**
 *
 * Gets the unique identifier of this instance.
 *
 * @returns  unique storage identifier for this account
 *
 */
- (NSString *)getId;

/**
 * Associates the specified value with the specified name.
 *
 * @param attrname - name with which the specified value is to be associated
 * @param val -value to be associated with the specified name
 */
- (void) setAttribute:(NSString *)attrname  value:(NSString *)val;

- (void) incrementNumUses;

@end
