//
//  MASUser+AuthIDIssuance.h
//  MASAuthID
//
//  Created by nimma01 on 27/03/18.
//  Copyright © 2018 CA. All rights reserved.
//

#import <MASFoundation/MASFoundation.h>
#import <MASAuthID/MASAIDIssuanceRequest.h>

@interface MASUser (AuthIDIssuance)

/**
 Creates a new AuthID Credential
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username and password are mandatory parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any.
 * If the create endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 * An example request object can be as below :
     MASAIDIssuanceRequest* issuanceRequest = [[MASAIDIssuanceRequest alloc] init];
     issuanceRequest.userName = username;
     issuanceRequest.password = password;
     issuanceRequest.orgName = orgName;
     issuanceRequest.customRequestData.isPublic = YES;
 
    [MASUser createAID:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the required parameters.
 
 */
+ (void)createAID:(MASAIDIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;

/**
 Reissue an existing AuthID credential.
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username and password are mandatory parameters.
 
 * If the reissue endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 *
 * An example request object can be as below :
     MASAIDIssuanceRequest* issuanceRequest = [[MASAIDIssuanceRequest alloc] init];
     issuanceRequest.userName = username;
     issuanceRequest.password = password;
     issuanceRequest.orgName = orgName;
     issuanceRequest.customRequestData.isPublic = YES;
 
     [MASUser reissueAID:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the appropriate parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any.
 
 */
+ (void)reissueAID:(MASAIDIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;

/**
 Download an existing AuthID credential.
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username are mandatory parameters.
 *
 * If the download endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 *
 * An example request object can be as below :
 MASAIDIssuanceRequest* issuanceRequest = [[MASAIDIssuanceRequest alloc] init];
 issuanceRequest.userName = username;
 issuanceRequest.password = password;
 issuanceRequest.orgName = orgName;
 issuanceRequest.customRequestData.isPublic = YES;
 
 [MASUser downloadAID:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the appropriate parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any. Look at responseobject.authID for the authID credential
 
 */
+ (void)downloadAID:(MASAIDIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;

/**
 Delete an existing AuthID credential.
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username are mandatory parameters.
 *
 * If the delete endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 *
 * An example request object can be as below :
 MASAIDIssuanceRequest* issuanceRequest = [[MASAIDIssuanceRequest alloc] init];
 issuanceRequest.userName = username;
 issuanceRequest.password = password;
 issuanceRequest.orgName = orgName;
 issuanceRequest.customRequestData.isPublic = YES;
 
 [MASUser deleteAID:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the appropriate parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any.
 
 */
+ (void)deleteAID:(MASAIDIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;

/**
 Disable an existing AuthID credential.
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username is a mandatory parameter.
 *
 * If the disable endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 *
 * An example request object can be as below :
     MASAIDIssuanceRequest* issuanceRequest = [[MASAIDIssuanceRequest alloc] init];
     issuanceRequest.userName = username;
     issuanceRequest.password = password;
     issuanceRequest.orgName = orgName;
     issuanceRequest.customRequestData.isPublic = YES;
 
     [MASUser disableAID:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the appropriate parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any.
 
 */
+ (void)disableAID:(MASAIDIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;

/**
 Enable an existing AuthID credential.
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username is a mandatory parameter.
 *
 * If the enable endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 *
 * An example request object can be as below :
 MASAIDIssuanceRequest* issuanceRequest = [[MASAIDIssuanceRequest alloc] init];
 issuanceRequest.userName = username;
 issuanceRequest.password = password;
 issuanceRequest.orgName = orgName;
 issuanceRequest.customRequestData.isPublic = YES;
 
 [MASUser enableAID:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the appropriate parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any.
 
 */
+ (void)enableAID:(MASAIDIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;

/**
 Fetch details about an existing AuthID credential.
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username is a mandatory parameter.
 *
 * If the fetch endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 *
 * An example request object can be as below :
 MASAIDIssuanceRequest* issuanceRequest = [[MASAIDIssuanceRequest alloc] init];
 issuanceRequest.userName = username;
 issuanceRequest.password = password;
 issuanceRequest.orgName = orgName;
 issuanceRequest.customRequestData.isPublic = YES;
 
 [MASUser fetchAID:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the appropriate parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any.
 
 */
+ (void)fetchAID:(MASAIDIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;

/**
 Reset an existing AuthID credential.
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username is a mandatory parameter.
 *
 * If the reset endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 *
 * An example request object can be as below :
 MASAIDIssuanceRequest* issuanceRequest = [[MASAIDIssuanceRequest alloc] init];
 issuanceRequest.userName = username;
 issuanceRequest.password = password;
 issuanceRequest.orgName = orgName;
 issuanceRequest.customRequestData.isPublic = YES;
 
 [MASUser resetAID:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the appropriate parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any.
 
 */
+ (void)resetAID:(MASAIDIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;
@end
