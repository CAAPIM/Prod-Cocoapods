//
//  MASUser+AuthID.h
//  MASAuthID
//
//  Created by Mahendra, Nimishakavi on 31/08/17.
//  Copyright © 2017 CA. All rights reserved.
//


#import <MASFoundation/MASFoundation.h>
#import <MASAuthID/AIDAccount.h>
#import <MASAuthID/MASAuthIDConfig.h>

@interface MASUser (AuthID){
    
}

# pragma mark - Authentication

// AID

/**
 Set Config Data from the given parameters
 
 * @param configData config data object. It contains parameters like sharedAuthID, groupContainerIdentifier and custom input.
 */
+(void)setConfig:(MASAuthIDConfig*)configData;



/**
 Creates and saves an Account object from the given parameters.
 
 * @param b64aid The base 64 AId.
 * @param nameSpace The url of Organization.The namespace should be prefixed by a
 * backslash '//' like the http url schemes.
 * @param completion An AIDAccount object initialized with User information.  On a successful completion or error.
 */

+(void)provisionAIDAccount:(NSString *)b64aid namespace:(NSString *)nameSpace deviceID:(NSString*)deviceID completion:(void(^)(AIDAccount *account, NSError *error))completion;

/**
 Authenticate a user via asynchronous request using the authID flow.
 
 * This will create an [MAUser currentUser] upon a successful result.
 
 * @param userID The userID of the user. This must be a combination of the username,organisation and namespace.
 * For example, username : USER1, organisation : DEFAULTORG, namespace : test the userID would be "USER1DEFAULTORGtest"
 * @param pin The pin of the user account.
 * @param completion The MASCompletionErrorBlock block that receives the results.
 * On a successful completion, the user
 * available via [MASUser currentUser] has been updated with the new information.
 */
+ (void)loginWithAID:(NSString *)userID pin:(NSString *)pin completion:(MASCompletionErrorBlock)completion;


/**
 Authenticate a user via asynchronous request using the authID flow.
 
 * This will create an [MAUser currentUser] upon a successful result.
 
 * @param userID The userID of the user. This must be a combination of the username,organisation and namespace. 
 * For example, username : USER1, organisation : DEFAULTORG, namespace : test the userID would be "USER1DEFAULTORGtest"
 * @param pin The pin of the user account.
 * @param policyName is the authentication policy that the user needs to be authenticated with. This
 *      is optional parameter and the default value is nil. This is typically used to login a user
 *      with multiple AuthID credentials.
 * @param customParameters Any custom parameters needed on server during the login call.
 *      This is optional and default value is nil.Parameters sent are added as value to the key'additionalParams'
 *      in the JSON structure.customParameters only accepts string values and does not accept custom objects.If
 *      any invalid object is added as value, the entire customParameters object is ignored.
 * @param completion The MASCompletionErrorBlock block that receives the results.
 * On a successful completion, the user available via [MASUser currentUser] has been updated with the new information.
 */
+ (void)loginWithAID:(NSString *)userID pin:(NSString *)pin authPolicy:(NSString*)policyName customParameters: (NSDictionary*)customParameters completion:(MASCompletionErrorBlock)completion;


/**
 Authenticate a user via asynchronous request using the authID flow and also retrieve the SMSession from SSO.
 
 * This will create an [MAUser currentUser] upon a successful result. If the user is already logged in, and if this API is called, it fetches a new SMSession but does not perform login.
 *
 * @param userID The userID of the user. This must be a combination of the username,organisation and namespace.
 * For example, username : USER1, organisation : DEFAULTORG, namespace : test the userID would be "USER1DEFAULTORGtest"
 * @param pin The pin of the user account.
 * @param completion The MASCompletionErrorBlock block that receives the results.On a successful completion, the user available via [MASUser currentUser] has been updated with the new information. The response contains a dictionary with SMSession and the cookie string.
 * By default, The SM Session cookie is also stored in the NSHTTPCookieStorage. Once this is stored, all subsequent network requests to the domain will carry the cookie in the request.
 */
+ (void)loginWithAIDSMSession:(NSString *)userID pin:(NSString *)pin completion:(MASResponseInfoErrorBlock)completion;


/**
 Authenticate a user via asynchronous request using the authID flow and also retrieve the SMSession from SSO.
 
 * This will create an [MAUser currentUser] upon a successful result. If the user is already logged in, and if this API is called, it fetches a new SMSession but does not perform login.
 *
 * @param userID The userID of the user. This must be a combination of the username,organisation and namespace.
 * For example, username : USER1, organisation : DEFAULTORG, namespace : test the userID would be "USER1DEFAULTORGtest"
 * @param pin The pin of the user account.
 * @param policyName is the authentication policy that the user needs to be authenticated with. This is optional parameter and the default value is nil. This is typically used to login a user with multiple AuthID credentials.
 * @param customParameters Any custom parameters needed on server during the login call.
 *   This is optional and default value is nil.Parameters sent are added as value to the key'additionalParams' in the JSON structure.customParameters only accepts string values and does not accept custom objects.If any invalid object is added as value, the entire customParameters object is ignored.
 * @param completion The MASCompletionErrorBlock block that receives the results.On a successful completion, the user available via [MASUser currentUser] has been updated with the new information. The response contains a dictionary with SMSession and the cookie string.
 * By default, The SM Session cookie is also stored in the NSHTTPCookieStorage. Once this is stored, all subsequent network requests to the domain will carry the cookie in the request.
 */
+ (void)loginWithAIDSMSession:(NSString *)userID pin:(NSString *)pin authPolicy:(NSString*)policyName customParameters:(NSDictionary*)customParameters completion:(MASResponseInfoErrorBlock)completion;



/**
 Retrieve the SMSession from SSO usign the AuthID credentials.
 
 * This API fetches a new SMSession but does not perform device registration with MAG. API also updates the SMSession cookie in the cookie store.
 * This API can also be used to refresh teh SMSession cookie.
 *
 * @param userID The userID of the user. This must be a combination of the username,organisation and namespace.
 * For example, username : USER1, organisation : DEFAULTORG, namespace : test the userID would be "USER1DEFAULTORGtest"
 * @param pin The pin of the user account.
 * @param policyName is the authentication policy that the user needs to be authenticated with. This is optional parameter and the default value is nil. This is typically used to login a user with multiple AuthID credentials.
 * @param customParameters Any custom parameters needed on server during the login call.
 *   This is optional and default value is nil.Parameters sent are added as value to the key'additionalParams' in the JSON structure.customParameters only accepts string values and does not accept custom objects.If any invalid object is added as value, the entire customParameters object is ignored.
 * @param completion The MASCompletionErrorBlock block that receives the results.On a successful completion, the user available via [MASUser currentUser] has been updated with the new information. The response contains a dictionary with SMSession and the cookie string.
 * By default, The SM Session cookie is also stored in the NSHTTPCookieStorage. Once this is stored, all subsequent network requests to the domain will carry the cookie in the request.
 */
+ (void)getSMSession:(NSString*)userID pin:(NSString*)pin authPolicy:(NSString*)policyName customParameters:(NSDictionary*)customParameters completion:(MASResponseInfoErrorBlock)completion;



/**
 Completes the MAG login flow by performing login with id token.
 
 * This API retrieves the id token persisted in the secure keychain storage and then uses it to complete the login flow with idtoken
 * Calling getSMSession API is pre-requisite to make sure a latest id token is stored.
 * @param completion The MASCompletionErrorBlock block that receives the results.On a successful completion, the user available via [MASUser currentUser] has been updated with the new information. The response contains a dictionary with SMSession and the cookie string.
 * @see getSMSession
 */
+ (void)loginWithCachedIdToken:(MASCompletionErrorBlock)completion;

/**
 Retrieves the Account object represented by the given identifier from the storage.
 
 * @param userID The userID of the user. This must be a combination of the username,organisation and namespace.
 * For example, username : USER1, organisation : DEFAULTORG, namespace : test the userID would be "USER1DEFAULTORGtest"
 * @param completion The complrtion block that receives the results, on a
 * successful completion.On failure the error object contains the error
 * information.
 */

+ (void)getAIDAccount:(NSString *)userID completion:(void(^)(AIDAccount *account, NSError *error))completion;



/**
 Removes the Account object represented by the given identifier from the storage.
 
 * @param userID The userID of the user. This must be a combination of the username,organisation and namespace.
 * For example, username : USER1, organisation : DEFAULTORG, namespace : test the userID would be "USER1DEFAULTORGtest"
 * @param completion The MASCompletionErrorBlock block that receives the results,
 * on a successful completion.On failure the error object contains the error
 * information.
 */
+ (void)removeAIDAccount:(NSString *)userID completion:(MASCompletionErrorBlock)completion;




/**
 Retrieves all Account objects from the storage.
 
 * @param completion The MASObjectsResponseErrorBlock block that receives the
 * results, on a successful completion the response would contain an array of
 * retrieved acccounts. On failure the error object contains the error
 * information.
 
 */

+ (void)getAllAIDAccounts:(MASObjectsResponseErrorBlock)completion;

@end
