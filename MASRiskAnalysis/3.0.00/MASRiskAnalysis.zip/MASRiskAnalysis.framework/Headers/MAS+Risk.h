//
//  MAS+Risk.h
//  MASRiskAnalysis
//
//  Created by nimma01 on 23/05/18.
//  Copyright © 2018 CA. All rights reserved.
//
#import <MASFoundation/MASFoundation.h>
#import <MASRiskAnalysis/MASRiskConfiguration.h>


@interface MAS (Risk)
{
    
}

/**
 * Set the handling state of the Risk evaluation by this framework. Sending YES to this
 * method will enable the framework to handle the Risk Evaluation related flow. When the
 * Server (RAS solution Kit) sends a challenge, typically an error code asking for
 * additional information like DeviceDNA details etc.
 * This API will interfere with the request and inserts the necessary header information
 * like Device DNA and invokes the original request again.
 * @param handle YES if you want the framework to enable it, NO if not.
 * @param riskHeaders custom headers that you can send to server through this API. Parameters like username and orgname can be sent using the configuration object in cases where an API is protected later by Risk.
 * @see MASRiskConfiguration
 * NO is the default.
 */
+ (void)setWillHandleRisk:(BOOL)handle withConfiguration:(MASRiskConfiguration*)riskHeaders;


/**
 * This API generates a new risk device identifier from the Risk fort server.
 * The API can automatically insert Device DNA into the request. But it is optional and can be configured.
 * @param userName is the userName of the user that is logged in
 * @param sendDeviceDNA set this to YES if DeviceDNA has to be inserted automatically. Set NO if DeviceDNA is not needed.
 * @param list you can pass a list of attributes that need to be disabled during device dna collection. This is considered only if sendDeviceDNA is set to YES.
 * @param completion The completion block that gives back the deviceID along with the response info from server and error if any.

 */
+ (void)generateDeviceID:(NSString*)userName sendDeviceDNA:(BOOL)sendDeviceDNA disableDDNAAttributes:(NSArray*)list completion:(void (^)(NSString* deviceID,NSDictionary* responseInfo,NSError* error))completion;

@end
