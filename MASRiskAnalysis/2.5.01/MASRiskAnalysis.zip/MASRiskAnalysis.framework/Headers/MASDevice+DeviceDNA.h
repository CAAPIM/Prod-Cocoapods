//
//  MASDevice+DeviceDNA.h
//  MASAdvancedAuth
//
//  Created by Sanches, Luis on 2017-02-23.
//  Copyright © 2017 CA Technologies. All rights reserved.
//

#import <MASFoundation/MASFoundation.h>

@protocol MASRMDeviceInventoryDelegate <NSObject>

/**
  This is callback method defined in DDNA SDK which is called back when SDK is finished
  with collecting device DNA attributes values used for the generating device signature.
 
  @param deviceDNA [in] device signature collected by DDNA sdk
*/

@required

- (void)didCompleteCollectingMASDeviceDNA:(NSString *)deviceDNA;

/**
  This is callback method defined in DDNA SDK which is called back in case of error
  occurance while collecting the device DNA attributes used for  generating device
  signature.
 
  @param error list in case of error collecting attributes of DDNA.error list contains NSError objects
 
 */

@optional
-(void)didFailCollectingDeviceDNA:(NSArray *)errorList;

@end

/**
 This category will expose methods from the DeviceDNA library to be used in the MASAdvancedAuth framework. The DeviceDNA library collects device date and is used in combination with the RiskMinder to evaluate if the device is trusted or not while accessing an API on the server side.
 */

@interface MASDevice (DeviceDNA)

/**
  The API collectMASDeviceDNA collects the  device DNA (device signature) based on the
  set of the device attributes. This method triggers device attribute collection and
  notifies calling object when it is done with the generation of the device signature.
  Invoke this method on main thread to retreive Location information. If the API is called on any other
  thread, Location information will not be fetched.
  This calls back the delegation method didCompletedCollectingMASDeviceDNA on the
  RMDeviceInventoryDelegate reference.

  @param  delegate : [in] This is reference to MASRMDeviceInventoryDelegate protocol implemented
                    by the application using DDNA SDK. DDNA SDK makes a call to an API
                    didCompletedCollectingMASDeviceDNA() once SDK is finished with
                   generating device signature. With this call back method, SDK returns
                    generated device DNA string in the calling object in the application.
 
 */

- (void)collectMASDeviceDNA:(id<MASRMDeviceInventoryDelegate>)delegate;

/**
 This API returns the device identifier set by the application by calling setMASRMDeviceId()
 API.

 @return device identifier for device, set by application for this device
 by calling setMASRMDeviceId()
 */

- (NSString *) getMASRMDeviceId;

/**
  This API sets the device identifier into SDK. The device identifier is received from the
  server for this device.
 
  @param  rmDeviceId : [in] device identifier for this device
  */

- (void) setMASRMDeviceId:(NSString *)rmDeviceId;

@end
