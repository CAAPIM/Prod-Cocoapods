//
//  MASDevice+DeviceDNA.h
//  MASAdvancedAuth
//
//  Created by Sanches, Luis on 2017-02-23.
//  Copyright © 2017 CA Technologies. All rights reserved.
//

#import <MASFoundation/MASFoundation.h>

@protocol MASRMDeviceInventoryDelegate <NSObject>

/**
 This is callback method defined in DDNA SDK which is called back when SDK is finished
 with collecting device DNA attributes values used for the generating device signature.
 
 @param deviceDNA [in] device signature collected by DDNA sdk
 */

@required

- (void)didCompleteCollectingMASDeviceDNA:(NSString *)deviceDNA;

/**
 This is callback method defined in DDNA SDK which is called back in case of error
 occurance while collecting the device DNA attributes used for  generating device
 signature.
 
 @param error list in case of error collecting attributes of DDNA.error list contains NSError objects
 
 */

@optional
-(void)didFailCollectingDeviceDNA:(NSArray *)errorList;

@end

/**
 This category will expose methods from the DeviceDNA library to be used in the MASAdvancedAuth framework. The DeviceDNA library collects device date and is used in combination with the RiskMinder to evaluate if the device is trusted or not while accessing an API on the server side.
 */

@interface MASDevice (DeviceDNA)

/*
 * Enumeration identifier for device attributes which can be disabled by application.
 *
 * If application wants to disable an attribute which is being collected as part of Device DNA, then
 * application needs to use this identifier and pass it to disableAttributes() API.
 * SDK makes use of this identifier while deriving device signature in the form of JSON
 * format. If an attribute is disabled by an application, the respective value for that
 * in JSON will have value "__DISABLE_ATTRIBUTE__"
 * e.g. "accessoriesAttached": "__DISABLE_ATTRIBUTE__"
 */
typedef enum {
    RA_DEVICE_NAME,
    RA_DEVICE_TYPE_FORMAT,
    RA_DEBUGGER,
    RA_PROCESSOR_ACTIVE,
    RA_PROCESSOR_BUS_SPEED,
    RA_ACCESSORIES_ATTACHED,
    RA_ACCESSORIES_NUMBER,
    RA_ACCESSORIES_HEADPHONE,
    RA_CELL_BROADCAST_ADDRESS,
    RA_CELL_IP_ADDRESS,
    RA_CELL_NETMASK_ADDRESS,
    RA_WIFI_NETMASK_ADDRESS,
    RA_WIFI_BROADCAST,
    RA_WIFI_ROUTER,
    RA_PROCESS_NAME,
    RA_DEVICE_ORIENTATION,
    RA_LOCALIZATION_LANGUAGE,
    RA_LOCALIZATION_CURRENCY,
    RA_LOCALIZATION_MEASUREMENT,
    RA_EXTERNAL_IP,
    RA_LOCATION,
    RA_CUSTOM,
    RA_PROXIMITY_SENSOR
} RA_DDNA_ATTRIBUTES;

/**
 The API collectMASDeviceDNA collects the  device DNA (device signature) based on the
 set of the device attributes. This method triggers device attribute collection and
 notifies calling object when it is done with the generation of the device signature.
 Invoke this method on main thread to retreive Location information. If the API is called on any other
 thread, Location information will not be fetched.
 This calls back the delegation method didCompleteCollectingMASDeviceDNA on the
 MASRMDeviceInventoryDelegate reference.
 
 @param  delegate : [in] This is reference to MASRMDeviceInventoryDelegate protocol implemented
 by the application using DDNA SDK. DDNA SDK makes a call to an API
 didCompletedCollectingMASDeviceDNA() once SDK is finished with
 generating device signature. With this call back method, SDK returns
 generated device DNA string in the calling object in the application.
 
 */

- (void)collectMASDeviceDNA:(id<MASRMDeviceInventoryDelegate>)delegate;


/**
 * The API collectMASDeviceDNA collects the  device DNA (device signature) based on the
 * set of the device attributes. This method triggers device attribute collection and
 * notifies calling object when it is done with the generation of the device signature.
 * Invoke this method on main thread to retreive Location information. If the API is called on any other
 * thread, Location information will not be fetched. This method can also be used to omit certain attributes during device dna collection.
 * This calls back the delegation method didCompleteCollectingMASDeviceDNA on the
 MASRMDeviceInventoryDelegate reference.
 
 @param  delegate : [in] This is reference to MASRMDeviceInventoryDelegate protocol implemented
 by the application using DDNA SDK. DDNA SDK makes a call to an API
 didCompletedCollectingMASDeviceDNA() once SDK is finished with
 generating device signature. With this call back method, SDK returns
 generated device DNA string in the calling object in the application.
 
 
 @param list : [NSArray] This is an array object containing RA_DDNA_ATTRIBUTES enumerator identifier for attributes used by the DDNA SDK. SDK will discard
 the attribute value while generating device signature.
 SDK make use of this identifier while deriving device signature in the form of JSON format. If an attribute is disabled by an application, the respectiv
 value for that in JSON for will have value "__DISABLE_ATTRIBUTE__"
 NSArray* list = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:RA_ACCESSORIES_ATTACHED], nil];
 e.g. "accessoriesAttached": "__DISABLE_ATTRIBUTE__"
 
 */

- (void)collectMASDeviceDNA : (id<MASRMDeviceInventoryDelegate>)delegate disableAttributes:(NSArray*)list;




/**
 This API sets the device identifier into SDK. The device identifier is received from the
 server for this device.
 
 @param  rmDeviceId : [in] device identifier for this device
 */

- (void)setMASRMDeviceId:(NSString *)rmDeviceId;



/**
 This API returns the device identifier set by the application by calling setMASRMDeviceId()
 API.
 
 @return device identifier for device, set by application for this device
 by calling setMASRMDeviceId()
 */

- (NSString *)getMASRMDeviceId;



/*
 * This API enables logging  while collecting the device DNA attributes.
 * This API logs the errors occured during device dna collection
 * @param  enable : [BOOL] should be set to TRUE if application needs to enable logging
 *
 * @return void
 *
 */
- (void)enableLogging : (BOOL)enable;


/*
 * This API returns log file content generated while collecting the device DNA.
 * The log file size is trucated at 2MB to avoid accumulation of logs.
 *
 * @param  void
 *
 * @return log file content as a string value.
 *
 */
- (NSString*)getLogs;



@end
