//
//  MASRiskConfiguration.h
//  MASRiskAnalysis
//
//  Created by nimma01 on 22/10/18.
//  Copyright © 2018 CA. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 This class acts as a model object that can represent the data that needs to be sent to server to carry out any Risk protected operation.
 If an API or end point is protected by Risk Assertion on server, it may require different parameters like username and orgname along with any other custom headers. This data can be filled in using an object of this class.
 */

@interface MASRiskConfiguration : NSObject
{
    
}

@property(nonatomic)NSString* userName;
@property(nonatomic)NSString* orgName;
@property(nonatomic)NSDictionary* customHeaders;

@end
