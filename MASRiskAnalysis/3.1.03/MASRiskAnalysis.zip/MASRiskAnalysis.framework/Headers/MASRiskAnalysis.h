//
//  MASRiskAnalysis.h
//  MASRiskAnalysis
//
//  Created by nimma01 on 07/09/17.
//  Copyright © 2017 CA. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MASRiskAnalysis.
FOUNDATION_EXPORT double MASRiskAnalysisVersionNumber;

//! Project version string for MASRiskAnalysis.
FOUNDATION_EXPORT const unsigned char MASRiskAnalysisVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MASRiskAnalysis/PublicHeader.h>

#import <MASRiskAnalysis/MASDevice+DeviceDNA.h>
#import <MASRiskAnalysis/MAS+Risk.h>
#import <MASRiskAnalysis/MASRiskConfiguration.h>
