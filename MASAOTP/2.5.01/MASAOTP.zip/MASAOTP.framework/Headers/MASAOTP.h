//
//  MASAOTP.h
//  MASAOTP
//
//  Created by nimma01 on 01/09/17.
//  Copyright © 2017 CA. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MASAOTP.
FOUNDATION_EXPORT double MASAOTPVersionNumber;

//! Project version string for MASAOTP.
FOUNDATION_EXPORT const unsigned char MASAOTPVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MASAOTP/PublicHeader.h>

#import <MASAOTP/MASUser+AOTP.h>
#import <MASAOTP/AOTPAccount.h>
