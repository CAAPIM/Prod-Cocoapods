//
//  MASUser+AOTPIssuance.h
//  MASAOTP
//
//  Created by nimma01 on 16/04/18.
//  Copyright © 2018 CA. All rights reserved.
//

#import <MASFoundation/MASFoundation.h>
#import <MASAOTP/MASAOTPIssuanceRequest.h>

@interface MASUser (AOTPIssuance)

/**
 Creates a new AOTP Credential
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username and password are mandatory parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any.
 * If the create endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 * An example request object can be as below :
 MASAOTPIssuanceRequest* issuanceRequest = [[MASAOTPIssuanceRequest alloc] init];
 issuanceRequest.userName = username;
 issuanceRequest.password = password;
 issuanceRequest.orgName = orgName;
 issuanceRequest.customRequestData.isPublic = YES;
 
 [MASUser createAOTP:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the required parameters.
 
 */
+ (void)createAOTP:(MASAOTPIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;


/**
 Reissue an existing AOTP credential.
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username and password are mandatory parameters.
 
 * If the reissue endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 *
 * An example request object can be as below :
 MASAOTPIssuanceRequest* issuanceRequest = [[MASAOTPIssuanceRequest alloc] init];
 issuanceRequest.userName = username;
 issuanceRequest.password = password;
 issuanceRequest.orgName = orgName;
 issuanceRequest.customRequestData.isPublic = YES;
 
 [MASUser reissueAOTP:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the appropriate parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any.
 
 */
+ (void)reissueAOTP:(MASAOTPIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;


/**
 Download an existing AOTP credential.
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username are mandatory parameters.
 *
 * If the download endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 *
 * An example request object can be as below :
 MASAOTPIssuanceRequest* issuanceRequest = [[MASAOTPIssuanceRequest alloc] init];
 issuanceRequest.userName = username;
 issuanceRequest.password = password;
 issuanceRequest.orgName = orgName;
 issuanceRequest.customRequestData.isPublic = YES;
 
 [MASUser downloadAOTP:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the appropriate parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any. Look at responseobject for the AOTP credentials
 
 */
+ (void)downloadAOTP:(MASAOTPIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;

/**
 Delete an existing AOTP credential.
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username are mandatory parameters.
 *
 * If the delete endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 *
 * An example request object can be as below :
 MASAOTPIssuanceRequest* issuanceRequest = [[MASAOTPIssuanceRequest alloc] init];
 issuanceRequest.userName = username;
 issuanceRequest.password = password;
 issuanceRequest.orgName = orgName;
 issuanceRequest.customRequestData.isPublic = YES;
 
 [MASUser deleteAOTP:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the appropriate parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any.
 
 */
+ (void)deleteAOTP:(MASAOTPIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;


/**
 Disable an existing AOTP credential.
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username is a mandatory parameter.
 *
 * If the disable endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 *
 * An example request object can be as below :
 MASAOTPIssuanceRequest* issuanceRequest = [[MASAOTPIssuanceRequest alloc] init];
 issuanceRequest.userName = username;
 issuanceRequest.password = password;
 issuanceRequest.orgName = orgName;
 issuanceRequest.customRequestData.isPublic = YES;
 
 [MASUser disableAOTP:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the appropriate parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any.
 
 */
+ (void)disableAOTP:(MASAOTPIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;


/**
 Enable an existing AOTP credential.
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username is a mandatory parameter.
 *
 * If the enable endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 *
 * An example request object can be as below :
 MASAOTPIssuanceRequest* issuanceRequest = [[MASAOTPIssuanceRequest alloc] init];
 issuanceRequest.userName = username;
 issuanceRequest.password = password;
 issuanceRequest.orgName = orgName;
 issuanceRequest.customRequestData.isPublic = YES;
 
 [MASUser enableAOTP:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the appropriate parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any.
 
 */
+ (void)enableAOTP:(MASAOTPIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;


/**
 Fetch details about an existing AOTP credential.
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username is a mandatory parameter.
 *
 * If the fetch endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 *
 * An example request object can be as below :
 MASAOTPIssuanceRequest* issuanceRequest = [[MASAOTPIssuanceRequest alloc] init];
 issuanceRequest.userName = username;
 issuanceRequest.password = password;
 issuanceRequest.orgName = orgName;
 issuanceRequest.customRequestData.isPublic = YES;
 
 [MASUser fetchAOTP:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the appropriate parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any.
 
 */
+ (void)fetchAOTP:(MASAOTPIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;


/**
 Reset an existing AOTP credential.
 
 * @param requestData request data object. It contains parameters like username, password, orgname and custom headers if any.
 * username is a mandatory parameter.
 *
 * If the reset endpoint on server is not protected by authentication, you need to set the isPublic property to YES. Otherwise SDK checks for access token and might fail the request if a valid access token is not found.
 *
 * An example request object can be as below :
 MASAOTPIssuanceRequest* issuanceRequest = [[MASAOTPIssuanceRequest alloc] init];
 issuanceRequest.userName = username;
 issuanceRequest.password = password;
 issuanceRequest.orgName = orgName;
 issuanceRequest.customRequestData.isPublic = YES;
 
 [MASUser resetAOTP:issuanceRequest completion:completionBlock];
 * Please look at Server API documentation to send the appropriate parameters.
 * @param completion The MASResponseObjectErrorBlock block that contains the entire NSHTTPURLResponse as well as parsed response object and error if any.
 
 */
+ (void)resetAOTP:(MASAOTPIssuanceRequest*)requestData completion:(MASResponseObjectErrorBlock)completion;

@end
