//
//  MASAOTPService.h
//  MASAOTP
//
//  Created by sidki02 on 20/03/19.
//  Copyright © 2019 CA. All rights reserved.
//

@import Foundation;

/**
 *  MASAOTPService is the base class for all services which are to be run during
 *  the internal service's lifecycle.
 */
@interface MASAOTPService : NSObject

/**
 * Protected initializer to be used by subclasses.  The default init of this
 * object will throw an exception to prevent usage.
 *
 * @return Returns an instance of the MASAOTPService.
 */
- (instancetype _Nullable)initProtected;

# pragma mark - Shared Service

/**
 * Retrieve the shared MASAOTPService singleton.
 *
 * Note, subclasses should override this version of the method.
 *
 * @return Returns the shared MASAOTPService singleton.
 */
+ (instancetype _Nullable)sharedService;

# pragma mark - Lifecycle

/**
 * Retreives the UUID assigned to a particular MASAOTPService subclass.  All subclasses MUST
 * implement this method with a unique value.
 *
 * @return Return the UUID assigned to the MASAOTPService subclass.
 */
+ (NSString *_Nullable)serviceUUID;

///--------------------------------------
/// @name Subclass Registry Methods
///-------------------------------------

# pragma mark - Subclass Registry Methods


/**
 An array of subclass information that is inherited and registered to MASAOTPService class
 
 @return An array of subclasses of MASAOTPService
 */
+ (NSArray * _Nullable)getSubclasses;



/**
 A method to register any inherited MASAOTPService class.
 
 @warning Any class that is subclassing `MASAOTPService` class MUST register through this method with its own service UUID.  `serviceUUID` MUST be unique to its service.
 
 @param subclass Class object of subclass
 @param serviceUUID NSString value of its own unique serviceUUID
 */
+ (void)registerSubclass:(Class _Nonnull)subclass serviceUUID:(NSString * _Nonnull)serviceUUID;

@end
