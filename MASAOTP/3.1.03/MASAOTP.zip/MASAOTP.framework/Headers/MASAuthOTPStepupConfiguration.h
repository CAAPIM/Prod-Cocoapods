//
//  MASStepupConfiguration.h
//  MASAOTP
//
//  Created by sidki02 on 04/03/2019.
//  Copyright © 2019 CA. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MASAuthOTPStepupConfiguration : NSObject
{
    
}
@property(nonatomic)NSString* userName;
@property(nonatomic)NSString* orgName;
@property(nonatomic)NSString* nameSpace;
@property(nonatomic)NSDictionary* customHeaders;

@end
