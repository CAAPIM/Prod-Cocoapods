//
//  MASAOTPCustomRequestData.h
//  MASAOTP
//
//  Created by nimma01 on 16/04/18.
//  Copyright © 2018 CA. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MASAOTPCustomRequestData : NSObject

@property (nonatomic)NSDictionary* headers;
@property (nonatomic)NSDictionary* queryParameters;
@property BOOL isPublic;

-(instancetype) init;

@end
