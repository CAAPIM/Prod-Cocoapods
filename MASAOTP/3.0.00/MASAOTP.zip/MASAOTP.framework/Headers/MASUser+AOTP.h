//
//  MASUser+AOTP.h
//  MASAOTP
//
//  Created by nimma01 on 01/09/17.
//  Copyright © 2017 CA. All rights reserved.
//

#import <MASFoundation/MASFoundation.h>
#import <MASAOTP/AOTPAccount.h>

@interface MASUser (AOTP)
{
    
}

// AOTP


/**
 Authenticate a user via asynchronous request using the AOTP flow.
 
 This will create an [MAUser currentUser] upon a successful result.
 
 * @param userID is unique identifier to identify the record, It is a combination of user name , organisation and nameSpace
 * with a :: delimiter. For example, username is 'testuser', organisation is 'defaultorg' and nameSpace is '//test', 
 * the userID will be "testuser::defaultorg:://test"
 * @param pin The pin of the user account.
 * @param completion The MASCompletionErrorBlock block that receives the results.  On a successful completion, the user
 * available via [MASUser currentUser] has been updated with the new information.
 */
+ (void)loginWithAOTP:(NSString *)userID pin:(NSString *)pin completion:(MASCompletionErrorBlock)completion;

/**
 provisionAccount stores the account information into the database.
 
 @param data is the account information in xml format.
 @param nameSpace is a namespace used for connecting to the provisoning server using http method.
 @param activationCode is provisioning authorization/activation code.
 @param pin is new PIN for camouflaging the account on local device.
 @param completion An AOTPAccount object initialized with User information. On a successful completion.
 */
+(void)provisionAOTPAccount:(NSString *)data nameSpace:(NSString *)nameSpace  code:(NSString *)activationCode newpin:(NSString *)pin deviceID:(NSString*)deviceID completion:(void (^)(AOTPAccount *, NSError *))completion;

/**
 This retrieves the AOTP account for the given userID and generates AOTP. AOTP is combination of numbers
 and alphabets depeding on the server side algorithm configuration. The maximum number of digits in the OTP number
 generated is controlled at server side configuration.
 
 * @param userID is unique identifier to identify the record, It is a combination of user name , organisation and nameSpace
 * with a :: delimiter. For example, username is 'testuser', organisation is 'defaultorg' and nameSpace is '//test',
 * the userID will be "testuser::defaultorg:://test"
 * @param pin  to generate AOTP.
 * @param propdic is a dictionary of properties to be used for generating OTP.
 * @param completion retrieves the AOTPAccount for the given userID. On a successful completion.
 */
+ (void)generateAOTP:(NSString *)userID pin:(NSString *)pin props:(NSDictionary *)propdic completion:(void(^)(NSString *aotp, NSError *error))completion;

/**
 This method finds the account information for the given key
 * @param userID is unique identifier to identify the record, It is a combination of user name , organisation and nameSpace
 * with a :: delimiter. For example, username is 'testuser', organisation is 'defaultorg' and nameSpace is '//test',
 * the userID will be "testuser::defaultorg:://test"
 * @param completion retrieves the AOTPAccount for the given userID. On a successful completion.
 */
+ (void)getAOTPAccount:(NSString *)userID completion:(void(^)(AOTPAccount *account, NSError *error))completion;

/**
 This method returns an array of all AOTPAccounts found on the device's storage system.
 
 @param completion array of AOTPAccount objects
 */
+ (void)getAllAOTPAccounts:(MASObjectsResponseErrorBlock)completion ;

/**
 This method Removes the AOTPAccount from the device.
 
 * @param userID is unique identifier to identify the record, It is a combination of user name , organisation and nameSpace
 * with a :: delimiter. For example, username is 'testuser', organisation is 'defaultorg' and nameSpace is '//test',
 * the userID will be "testuser::defaultorg:://test"
 * @param completion The MASObjectsResponseErrorBlock block that receives the results. On a successful completion.
 */
+ (void)removeAOTPAccount:(NSString *)userID completion:(MASCompletionErrorBlock)completion;

/**
 This method fetches and returns the roaming keys of the AOTP account of the userID specified
 
 @param aotpAccount AOTPAccount object.
 @param completion retrieves the keys.
 */
+(void)getRoamingKeys:(AOTPAccount *)aotpAccount completion:(void(^)(NSString *keys, NSError *error))completion;


/**
 
 The API used to sync counter or timer when its out of sync from server
 
 @param aotpAccount AOTPAccount object.
 @param syncvalue
 @param completion The MASObjectsResponseErrorBlock block that receives the results. On a successful completion.
 */
+(void)resync:(AOTPAccount *)aotpAccount value:(NSString *)syncvalue completion:(MASCompletionErrorBlock)completion;

@end
