//
//  MASAOTPIssuanceRequest.h
//  MASAOTP
//
//  Created by nimma01 on 16/04/18.
//  Copyright © 2018 CA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MASAOTP/MASAOTPCustomRequestData.h>

@interface MASAOTPIssuanceRequest : NSObject

@property NSString* userName;
@property NSString* password;
@property NSString* orgName;
@property NSString* profileName;
@property NSString* clientTxID;
@property MASAOTPCustomRequestData* customRequestData;

-(instancetype) init;

@end
