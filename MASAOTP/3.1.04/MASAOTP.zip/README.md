Back to > [iOS Mobile SDK](https://github.com/CAAPIM/iOS-MAS-SDK)
<hr/>

# MASAOTP Framework for iOS

## Overview
To secure online transactions from Man-in-the-Middle (MITM) and other related attacks, CA Strong Authentication provides client applications that are based on CA Mobile PKI ,CA Mobile OTP credentials and CA Mobile API Gateway. These software credentials provide two-factor authentication and are based on the patented Cryptographic Camouflage technique for securely storing keys. You can develop your own client application by using this Software Development Kit (SDK).

## Project Dependency

. MASFoundation framework

. CA Mobile OTP iOS SDK version 8.2.1

## Get Started

### Step 1: Setting up environment / cloning repos

Clone this repo into a folder structure with a root folder like: **Projects -> iOS-MASAOTP**

Clone MASFoundation repo into the same folder structure under the same root folder like: **Projects -> iOS-MASFoundation** or get a stable version of the MASFoundation.framework

For documentation, visit our [developer site][docs].

### Step 2: Setting up iOS-MASAOTP Xcode project

Open the MASAuthID project in Xcode and drag and drop the dependencies into the project as below:

. iOS-MASFoundation project into the iOS-MASAuthID project (add it as target dependency in the Building Phases tab) or if you have a MASFoundation.framework just link that framework to MASAuthID project (under Link Binary With Libraries section)

. Copy libotp.a library (part of the CA Mobile OTP SDK 8.2.1 package) into the Vendor->lib folder of iOS-MASAOTP project in Finder. Later add it to the project in Xcode as well in the same folder structure.

## Build the SDK

### Step 1

Change the schema of the project to UniversalFramework and build the Xcode project. i.e. For building MASAOTP framework you would open MASAOTP iOS project in Xcode, change the schema to UniversalMASAOTP and run build.

P.S. The build can run targetting simulator or device, it doesnt matter once the script will be building both and merging them into a simple framework file that can be used for either in simulator or device deployment.

### Step 2

The framework file will be generated into a folder called iOS_SDK into the same root folder defined previously by you. i.e. Projects -> iOS_SDK

## How to install the SDK to Application

Once you have built both MASAOTP and MASFoundation framework (they are two different projects and should be opened separately in Xcode). You can drag and drop the framework files into your demo project and start working with them.
There are few build settings that need to be modified:

 1. Make sure you add -ObjC linker flag. Under the **Build Settings->Other linker flags** add -ObjC (this is to make sure all the categories are loaded).
  
 2. Also since MASAOTP.framework and MASFoundation.framework are dynamic frameworks, make sure you embedd them. Go to **General->Embedded Binaries** and add the MASAOTP.framework and MASFoundation.framework

## How You Can Contribute

Contributions are welcome and much appreciated. To learn more, see the [Contribution Guidelines][contributing].


## License

Copyright (c) 2016 CA. All rights reserved.

This software may be modified and distributed under the terms
of the MIT license. See the [LICENSE][license-link] file for details.

 [mag]: https://docops.ca.com/mag
 [mas.ca.com]: http://mas.ca.com/
 [docs]: http://mas.ca.com/docs/
 [blog]: http://mas.ca.com/blog/

 [releases]: ../../releases
 [contributing]: /CONTRIBUTING.md
 [license-link]: /LICENSE
