# Version 1.2.03

- Release tag to align with MASFoundation framework.
- ***No fixes for this framework***


# Version 1.2.01

### Bug fixes
- Version number and version string returned incorrect values. [MCT-437]

### New features

None.

### Deprecated methods

None.



 [mag]: https://docops.ca.com/mag
 [mas.ca.com]: http://mas.ca.com/
 [docs]: http://mas.ca.com/docs/
 [blog]: http://mas.ca.com/blog/

 [releases]: ../../releases
 [contributing]: /CONTRIBUTING.md
 [license-link]: /LICENSE

