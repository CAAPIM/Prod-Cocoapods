# Version 1.7.00

### Bug fixes
None.

### New features
None.

# Version 1.6.10

### Bug fixes
None.

### New features
None.

# Version 1.6.00

### Bug fixes
None.

### New features
None.

# Version 1.5.00

NOTE: From this version on the frameworks changed to Dynamic instead of Static library

### Bug fixes
None.

### New Features
- The SDK supports dynamic framework. All you need to do is update your Xcode settings. [US367604]

# Version 1.4.00

### Bug fixes
None.

# Version 1.3.01

### Bug fixes
- Added nullability annotations to certain interfaces. [US238629]
- Improved error handling in the case of missing parameters. [US238629]

# Version 1.2.03

- Release tag to align with MASFoundation framework.
- ***No fixes for this framework***

# Version 1.2.01

### Bug fixes
- Version number and version string returned incorrect values. [MCT-437]

### New features

None.

### Deprecated methods

None.



 [mag]: https://docops.ca.com/mag
 [mas.ca.com]: http://mas.ca.com/
 [docs]: http://mas.ca.com/docs/
 [blog]: http://mas.ca.com/blog/

 [releases]: ../../releases
 [contributing]: /CONTRIBUTING.md
 [license-link]: /LICENSE

